from django.apps import AppConfig


class MyUsersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'my_users'
